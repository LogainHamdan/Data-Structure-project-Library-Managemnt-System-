package librarymanagementsystem;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.swing.*;

public class LibraryManagementSystem {

    // instance variables for the main GUI
    private JFrame frame;
    private JPanel loginPanel;
    private JPanel dashboardPanel;
    private JPanel dashboardPanelAdmin;
    private JPanel adminOrUserPanel;

    // instance variables for the login panel
    private JLabel emailLabel;
    private JTextField emailField;
    private JLabel passwordLabel;
    private JPasswordField passwordField;
    private JButton signUpButton;
    private JButton loginButton;

    private JButton adminButton;
    private JButton userButton;

    // instance variables for the dashboard panel
    private JButton insertBookButton;
    private JButton deleteBookButton;
    private JButton searchBookButton;
    private JButton buyBookButton;
    private JButton displayBoughtBooksButton;

    // create a Logout button
    private JButton logoutButton1;

    private JButton logoutButton2;
    // instance variables for storing data
    private HashMap<String, User> users;
    private TreeMap<Integer, Book> books;

    public static void main(String[] args) {
        new LibraryManagementSystem().showGUI();
    }

    public void showGUI() {
        // create the frame and set its properties
        frame = new JFrame("Library Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 150);
        frame.setLocationRelativeTo(null);

        // initialize the data structures
        users = new HashMap<>();
        books = new TreeMap<>();

        // read the data from the file
        readData();

        // create the login panel
        loginPanel = new JPanel();
        emailLabel = new JLabel("Email:");
        emailField = new JTextField(20);
        passwordLabel = new JLabel("Password:");
        passwordField = new JPasswordField(20);
        signUpButton = new JButton("Sign Up");
        loginButton = new JButton("Login");
        loginPanel.add(emailLabel);
        loginPanel.add(emailField);
        loginPanel.add(passwordLabel);
        loginPanel.add(passwordField);
        loginPanel.add(signUpButton);
        loginPanel.add(loginButton);

        adminOrUserPanel = new JPanel();
        adminButton = new JButton("Admin");
        userButton = new JButton("User");
        adminOrUserPanel.add(adminButton);
        adminOrUserPanel.add(userButton);

        adminButton.addActionListener(new adminListener());
        userButton.addActionListener(new userListener());

        // create the dashboard panel
        dashboardPanel = new JPanel();

        searchBookButton = new JButton("Search Book");
        buyBookButton = new JButton("Buy Book");
        displayBoughtBooksButton = new JButton("Display Bought Books");
        logoutButton1 = new JButton("Logout");

        dashboardPanel.add(searchBookButton);
        dashboardPanel.add(buyBookButton);
        dashboardPanel.add(displayBoughtBooksButton);
        dashboardPanel.add(logoutButton1);

        dashboardPanelAdmin = new JPanel();
        insertBookButton = new JButton("Insert Book");
        deleteBookButton = new JButton("Delete Book");
        logoutButton2 = new JButton("Logout");
        dashboardPanelAdmin.add(insertBookButton);
        dashboardPanelAdmin.add(deleteBookButton);
        dashboardPanelAdmin.add(logoutButton2);

        // add the login panel to the frame
        frame.add(loginPanel);

        // add event listeners for the buttons
        signUpButton.addActionListener(new SignUpListener());
        loginButton.addActionListener(new LoginListener());
        insertBookButton.addActionListener(new InsertBookListener());
        deleteBookButton.addActionListener(new DeleteBookListener());
        searchBookButton.addActionListener(new SearchBookListener());
        buyBookButton.addActionListener(new BuyBookListener());
        displayBoughtBooksButton.addActionListener(new DisplayBoughtBooksListener());
        logoutButton1.addActionListener(new LogoutButtonListener1());
        logoutButton2.addActionListener(new LogoutButtonListener2());

        // show the frame
        frame.setVisible(true);

    }

    class adminListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            frame.getContentPane().removeAll();
            frame.add(dashboardPanelAdmin);
            frame.revalidate();
            frame.repaint();
            dashboardPanelAdmin.setVisible(true);

        }

    }

    class userListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            frame.getContentPane().removeAll();
            frame.add(dashboardPanel);
            frame.revalidate();
            frame.repaint();
            dashboardPanel.setVisible(true);

        }

    }

    // inner class for handling the Sign Up button in the login panel
    class SignUpListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            // create a new window for collecting the user's information
            JFrame signUpFrame = new JFrame("Sign Up");
            signUpFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            // create a panel for the input fields
            JPanel inputPanel = new JPanel();
            inputPanel.setLayout(new GridLayout(5, 2));

            // create labels and input fields for the user's email, password, first name, last name, and age
            JLabel emailLabel = new JLabel(" Email:");
            JTextField emailField = new JTextField(18);
            JLabel passwordLabel = new JLabel(" Password:");
            JPasswordField passwordField = new JPasswordField(18);
            JLabel firstNameLabel = new JLabel(" First Name:");
            JTextField firstNameField = new JTextField(18);
            JLabel lastNameLabel = new JLabel(" Last Name:");
            JTextField lastNameField = new JTextField(18);
            JLabel ageLabel = new JLabel(" Age:");
            JTextField ageField = new JTextField(18);

            // add the labels and input fields to the panel
            inputPanel.add(emailLabel);
            inputPanel.add(emailField);
            inputPanel.add(passwordLabel);
            inputPanel.add(passwordField);
            inputPanel.add(firstNameLabel);
            inputPanel.add(firstNameField);
            inputPanel.add(lastNameLabel);
            inputPanel.add(lastNameField);
            inputPanel.add(ageLabel);
            inputPanel.add(ageField);

            // create a panel for the buttons
            JPanel buttonPanel = new JPanel();

            // create a Save button
            JButton saveButton = new JButton("Save");

            // add an action listener for the Save button
            saveButton.addActionListener((ActionEvent event1) -> {
                // get the user's information from the input fields
                String email = emailField.getText();
                String password = new String(passwordField.getPassword());
                String firstName = firstNameField.getText();
                String lastName = lastNameField.getText();
                int age = Integer.parseInt(ageField.getText());

                // create a new user with the given information
                User user = new User(email, password);
                user.setFirstName(firstName);
                user.setLastName(lastName);
                user.setAge(age);

                // add the user to the HashMap
                users.put(email, user);

                // write the data to the file
                writeData();

                // show a message indicating that the user was registered successfully
                JOptionPane.showMessageDialog(signUpFrame, "User : { " + firstName + " " + lastName + " } registered successfully!", "Success",
                        JOptionPane.INFORMATION_MESSAGE);

                // close the window
                signUpFrame.dispose();
            });

            // create a Cancel button
            JButton cancelButton = new JButton("Cancel");

            // add an action listener for the Cancel button
            cancelButton.addActionListener((ActionEvent event1) -> {
                // close the window
                signUpFrame.dispose();
            });

            // add the Save and Cancel buttons to the button panel
            buttonPanel.add(saveButton);
            buttonPanel.add(cancelButton);

            // add the input panel and button panel to the frame
            signUpFrame.add(inputPanel, BorderLayout.CENTER);
            signUpFrame.add(buttonPanel, BorderLayout.SOUTH);

            // pack and show the frame
            signUpFrame.pack(); //sizes the frame so that all its contents are at or above their preferred sizes.
            //An alternative to pack is to establish a frame size explicitly by calling setSize() or setBounds()
            signUpFrame.setVisible(true);
            signUpFrame.setLocationRelativeTo(null);

        }
    }

    // inner class for the Login button listener
    class LoginListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            // get the email and password from the input fields
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            // check if the email and password match an existing user
            User user = users.get(email);
            if (user != null && user.getPassword().equals(password)) {
                // switch to the dashboard panel
                frame.getContentPane().removeAll();
                frame.add(adminOrUserPanel);
                frame.revalidate();
                frame.repaint();
                //way to remove all the current panel

                adminOrUserPanel.setVisible(true);
            } else {
                // show an error message
                JOptionPane.showMessageDialog(frame, "Invalid email or password! TRY AGAIN !!");
            }
        }
    }

    class InsertBookListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            // show a dialog for inserting a new book
            JTextField idField = new JTextField(5);
            JTextField titleField = new JTextField(20);
            JTextField authorField = new JTextField(20);
            JTextField quantityField = new JTextField(5);
            JTextField isbnField = new JTextField(20);
            JTextField publisherField = new JTextField(20);
            JTextField pagesField = new JTextField(5);
            JTextField ratingField = new JTextField(5);
            JTextField publishedField = new JTextField(20);
            JPanel insertBookPanel = new JPanel();
            insertBookPanel.add(new JLabel("ID:"));
            insertBookPanel.add(idField);
            insertBookPanel.add(new JLabel("Title:"));
            insertBookPanel.add(titleField);
            insertBookPanel.add(new JLabel("Author:"));
            insertBookPanel.add(authorField);
            insertBookPanel.add(new JLabel("Quantity:"));
            insertBookPanel.add(quantityField);
            insertBookPanel.add(new JLabel("ISBN:"));
            insertBookPanel.add(isbnField);
            insertBookPanel.add(new JLabel("Publisher:"));
            insertBookPanel.add(publisherField);
            insertBookPanel.add(new JLabel("Pages:"));
            insertBookPanel.add(pagesField);
            insertBookPanel.add(new JLabel("Rating:"));
            insertBookPanel.add(ratingField);
            insertBookPanel.add(new JLabel("Published:"));
            insertBookPanel.add(publishedField);
            int result = JOptionPane.showConfirmDialog(null, insertBookPanel, "Insert Book",
                    JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                // get the values from the input fields
                int id = Integer.parseInt(idField.getText());
                String title = titleField.getText();
                String author = authorField.getText();
                int quantity = Integer.parseInt(quantityField.getText());
                String isbn = isbnField.getText();
                String publisher = publisherField.getText();
                int pages = Integer.parseInt(pagesField.getText());
                int rating = Integer.parseInt(ratingField.getText());
                String published = publishedField.getText();

                // create a new Book object with the given values
                Book book = new Book(id, title, author, quantity, isbn, publisher, pages, rating, published);

                // add the book to the TreeMap
                books.put(id, book);

                // show a message dialog indicating that the book has been inserted
                JOptionPane.showMessageDialog(frame, "Book inserted successfully!");
            }

        }
    }

// inner class for the Delete Book button listener
    class DeleteBookListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            // show a dialog for deleting a book
            JTextField idField = new JTextField(5);
            JPanel deleteBookPanel = new JPanel();
            deleteBookPanel.add(new JLabel("ID:"));
            deleteBookPanel.add(idField);
            int result = JOptionPane.showConfirmDialog(null, deleteBookPanel, "Delete Book",
                    JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                // get the ID of the book to be deleted
                int id = Integer.parseInt(idField.getText());

                // remove the book from the TreeMap
                if (books.containsKey(id)) {
                    books.remove(id);
                    JOptionPane.showMessageDialog(frame, "Book deleted successfully!");
                } else {
                    JOptionPane.showMessageDialog(frame, "Book not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }

            }
        }
    }

// inner class for the Search Book button listener
    class SearchBookListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            // show a dialog for searching a book
            JTextField idField = new JTextField(5);
            JPanel searchBookPanel = new JPanel();
            searchBookPanel.add(new JLabel("ID:"));
            searchBookPanel.add(idField);
            int result = JOptionPane.showConfirmDialog(null, searchBookPanel, "Search Book",
                    JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                // get the ID of the book to be searched
                int id = Integer.parseInt(idField.getText());

                // get the book from the TreeMap
                Book book = books.get(id);

                if (book != null) {
                    // show the details of the book in a message dialog
                    JOptionPane.showMessageDialog(frame, book.getDetails(), "Book Details",
                            JOptionPane.INFORMATION_MESSAGE);
                } else {
                    // show an error message
                    JOptionPane.showMessageDialog(frame, "Book not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

// inner class for the Buy Book button listener
    class BuyBookListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            // get the email of the logged in user
            String email = emailField.getText();

            // get the user's list of bought books
            User user = users.get(email);
            ArrayList<Book> boughtBooks = user.getBoughtBooks();

            // show a dialog for buying a book
            JTextField idField = new JTextField(5);
            JPanel buyBookPanel = new JPanel();
            buyBookPanel.add(new JLabel("ID:"));
            buyBookPanel.add(idField);
            int result = JOptionPane.showConfirmDialog(null, buyBookPanel, "Buy Book", JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                // get the ID of the book to be bought
                int id = Integer.parseInt(idField.getText());

                // get the book from the TreeMap
                Book book = books.get(id);

                if (book != null && book.getQuantity() > 0) {
                    // decrease the quantity of the book
                    book.setQuantity(book.getQuantity() - 1);

                    // add the book to the user's list of bought books
                    boughtBooks.add(book);

                    // show a message dialog indicating that the book has been bought
                    JOptionPane.showMessageDialog(frame, "Book bought successfully!");
                } else {
                    // show an error message
                    JOptionPane.showMessageDialog(frame, "Book not found!", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

// inner class for the Display Bought Books button listener
    class DisplayBoughtBooksListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            // get the email of the logged in user
            String email = emailField.getText();

            // get the user's list of bought books
            User user = users.get(email);
            ArrayList<Book> boughtBooks = user.getBoughtBooks();

            // check if the user has bought any books
            if (boughtBooks.isEmpty()) {
                // show a message dialog indicating that the user has not bought any books
                JOptionPane.showMessageDialog(frame, "You have not bought any books!", "Error", JOptionPane.ERROR_MESSAGE);
            } else {
                // create a dialog for displaying the bought books
                JFrame displayDialog = new JFrame("Bought Books");
                displayDialog.setSize(750, 220);

                // create a panel for displaying the books
                JPanel displayPanel = new JPanel();

                // add a label for each bought book to the panel
                boughtBooks.stream().map((book) -> new JLabel(book.getDetails())).forEachOrdered((bookLabelid) -> {
                    displayPanel.add(bookLabelid);
                });

                // add the panel to the dialog
                displayDialog.add(displayPanel);

                // show the dialog
                displayDialog.setVisible(true);
                displayDialog.setLocationRelativeTo(null);

            }
        }
    }

    class LogoutButtonListener1 implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            // write the data to the file
            writeData();

            // show the login panel
            frame.getContentPane().removeAll();
            frame.add(loginPanel);
            frame.revalidate();
            frame.repaint();
            loginPanel.setVisible(true);

            // clear the input fields
            emailField.setText("");
            passwordField.setText("");
            // clear the input fields
            emailField.setText("");
            passwordField.setText("");
        }

    }

    class LogoutButtonListener2 implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
            // write the data to the file
            writeData();

            // show the login panel
            frame.getContentPane().removeAll();
            frame.add(loginPanel);
            frame.revalidate();
            frame.repaint();
            loginPanel.setVisible(true);

            // clear the input fields
            emailField.setText("");
            passwordField.setText("");
        }

    }
// method for reading the data from the file

    private void readData() {
        try {
            // create a FileReader object for reading the file
            FileReader fileReader = new FileReader("C:\\Users\\pc\\Desktop\\LibraryManagementSystem\\data.txt");

            try ( // create a BufferedReader object for reading the file
                    BufferedReader bufferedReader = new BufferedReader(fileReader)) {
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    // split the line into components
                    String[] components = line.split(",");

                    // the first component is the email of the user
                    String email = components[0];

                    // the second component is the password of the user
                    String password = components[1];

                    // create a new User object with the email and password
                    User user = new User(email, password);

                    // add the user to the HashMap
                    users.put(email, user);

                    // the remaining components are the books that the user has bought
                    ArrayList<Book> boughtBooks = user.getBoughtBooks();
                    for (int i = 2; i < components.length; i++) {
                        // get the ID of the book

                        int id = Integer.parseInt(components[i]);

                        // get the book from the TreeMap
                        Book book = books.get(id);

                        // add the book to the user's list of bought books
                        boughtBooks.add(book);
                    }
                }
                // close the file
            }
        } catch (FileNotFoundException e) {
            // show an error message if the file is not found
            JOptionPane.showMessageDialog(frame, "File not found!", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException e) {
            // show an error message if there is an IO exception
            JOptionPane.showMessageDialog(frame, "Error reading file!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // method for writing the data to the file
    private void writeData() {
        try {
            // create a FileWriter object for writing to the file
            FileWriter fileWriter = new FileWriter("C:\\Users\\pc\\Desktop\\LibraryManagementSystem\\data.txt");

            // write each user's data to the file
            try ( // create a BufferedWriter object for writing to the file
                    BufferedWriter bufferedWriter = new BufferedWriter(fileWriter)) {
                // write each user's data to the file
                for (Map.Entry<String, User> entry : users.entrySet()) {
                    User user = entry.getValue(); //to get the user object which is value in the hashMap 'users'.
                    String email = user.getEmail();
                    String password = user.getPassword();
                    ArrayList<Book> boughtBooks = user.getBoughtBooks();

                    // write the email and password to the file
                    bufferedWriter.write(email + "," + password);

                    // write the IDs of the bought books to the file
                    for (Book book : boughtBooks) {
                        int id = book.getId();

                        bufferedWriter.write("," + id);
                    }

                    // write a newline character
                    bufferedWriter.newLine();
                }
                // close the file
            }
        } catch (IOException e) {
            // show an error message if there is an IO exception
            JOptionPane.showMessageDialog(frame, "Error writing to file!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
